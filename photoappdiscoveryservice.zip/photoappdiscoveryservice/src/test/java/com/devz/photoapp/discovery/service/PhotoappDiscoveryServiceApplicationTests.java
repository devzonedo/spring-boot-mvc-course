package com.devz.photoapp.discovery.service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PhotoappDiscoveryServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
