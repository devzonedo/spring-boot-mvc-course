package accountservice.photoaccountservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PhotoaccountServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(PhotoaccountServiceApplication.class, args);
	}

}
